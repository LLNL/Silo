autoreconf -v --install || exit 1
